<?php
/**
 * Template part for displaying posts pagination.
 */

the_posts_pagination();
